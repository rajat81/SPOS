int String abc;
int num = 4.5;
int num;
String name="Rajat";
String name;
int num = 15;
String int abx;
